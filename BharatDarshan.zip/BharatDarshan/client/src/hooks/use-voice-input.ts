import { useState, useCallback, useRef } from "react";

interface SpeechRecognitionEvent extends Event {
  results: SpeechRecognitionResultList;
  resultIndex: number;
}

interface SpeechRecognition extends EventTarget {
  continuous: boolean;
  interimResults: boolean;
  lang: string;
  onresult: (event: SpeechRecognitionEvent) => void;
  onerror: (event: SpeechRecognitionErrorEvent) => void;
  onend: () => void;
  start: () => void;
  stop: () => void;
}

interface SpeechRecognitionErrorEvent extends Event {
  error: string;
  message?: string;
}

declare global {
  interface Window {
    SpeechRecognition: new () => SpeechRecognition;
    webkitSpeechRecognition: new () => SpeechRecognition;
  }
}

export function useVoiceInput() {
  const [isListening, setIsListening] = useState(false);
  const [isSupported, setIsSupported] = useState(false);
  const recognitionRef = useRef<SpeechRecognition | null>(null);

  const initializeRecognition = useCallback(() => {
    if (typeof window === "undefined") return false;

    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    
    if (!SpeechRecognition) {
      setIsSupported(false);
      return false;
    }

    setIsSupported(true);
    
    if (!recognitionRef.current) {
      recognitionRef.current = new SpeechRecognition();
      recognitionRef.current.continuous = true;
      recognitionRef.current.interimResults = true;
      recognitionRef.current.lang = 'hi-IN'; // Hindi (India)
    }

    return true;
  }, []);

  const startListening = useCallback((
    onResult: (transcript: string, isFinal: boolean) => void,
    onError?: (error: string) => void
  ) => {
    if (!initializeRecognition()) {
      onError?.("Speech recognition is not supported in this browser");
      return;
    }

    if (!recognitionRef.current) return;

    setIsListening(true);

    recognitionRef.current.onresult = (event: SpeechRecognitionEvent) => {
      let transcript = '';
      let isFinal = false;

      for (let i = event.resultIndex; i < event.results.length; i++) {
        const result = event.results[i];
        transcript += result[0].transcript;
        if (result.isFinal) {
          isFinal = true;
        }
      }

      onResult(transcript, isFinal);
    };

    recognitionRef.current.onerror = (event: SpeechRecognitionErrorEvent) => {
      setIsListening(false);
      let errorMessage = "Voice recognition error occurred";

      switch (event.error) {
        case 'network':
          errorMessage = "Network error occurred during voice recognition";
          break;
        case 'not-allowed':
          errorMessage = "Microphone access was denied. Please allow microphone access and try again";
          break;
        case 'no-speech':
          errorMessage = "No speech was detected. Please try speaking again";
          break;
        case 'aborted':
          errorMessage = "Voice recognition was aborted";
          break;
        case 'audio-capture':
          errorMessage = "No microphone was found. Please check your microphone and try again";
          break;
        case 'language-not-supported':
          errorMessage = "Hindi language is not supported by your browser";
          break;
        default:
          errorMessage = `Voice recognition error: ${event.error}`;
      }

      onError?.(errorMessage);
    };

    recognitionRef.current.onend = () => {
      setIsListening(false);
    };

    try {
      recognitionRef.current.start();
    } catch (error) {
      setIsListening(false);
      onError?.("Failed to start voice recognition");
    }
  }, [initializeRecognition]);

  const stopListening = useCallback(() => {
    if (recognitionRef.current && isListening) {
      recognitionRef.current.stop();
      setIsListening(false);
    }
  }, [isListening]);

  return {
    isListening,
    isSupported,
    startListening,
    stopListening,
    initializeRecognition
  };
}