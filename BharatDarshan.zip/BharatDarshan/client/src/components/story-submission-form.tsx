import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { insertStorySchema } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useVoiceInput } from "@/hooks/use-voice-input";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Mic, MicOff } from "lucide-react";

const formSchema = insertStorySchema.extend({
  name: z.string().min(1, "Name is required").min(2, "Name must be at least 2 characters"),
  title: z.string().min(1, "Title is required").min(3, "Title must be at least 3 characters"),
  description: z.string().min(1, "Description is required").min(10, "Description must be at least 10 characters")
});

type FormData = z.infer<typeof formSchema>;

export default function StorySubmissionForm() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { isListening, isSupported, startListening, stopListening, initializeRecognition } = useVoiceInput();

  const form = useForm<FormData>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: "",
      title: "",
      description: ""
    }
  });

  const mutation = useMutation({
    mutationFn: async (data: FormData) => {
      const response = await fetch("/api/stories", {
        method: "POST",
        body: JSON.stringify(data),
        headers: {
          "Content-Type": "application/json"
        }
      });
      
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Story submitted successfully!",
        description: "Thank you for sharing your cultural story with us."
      });
      form.reset();
      queryClient.invalidateQueries({ queryKey: ["/api/stories"] });
    },
    onError: (error: any) => {
      toast({
        variant: "destructive",
        title: "Submission failed",
        description: error.message || "There was an error submitting your story. Please try again."
      });
    }
  });

  const handleVoiceInput = () => {
    // Check if speech recognition is supported
    if (!initializeRecognition()) {
      alert("Speech recognition is not supported in your browser. Please use a modern browser like Chrome or Edge.");
      return;
    }

    if (isListening) {
      stopListening();
      return;
    }

    startListening(
      (transcript: string, isFinal: boolean) => {
        // Update the description field with the transcript
        const currentValue = form.getValues("description");
        
        if (isFinal) {
          // Add the final transcript to the existing text
          const newValue = currentValue + (currentValue ? " " : "") + transcript.trim();
          form.setValue("description", newValue);
        }
      },
      (error: string) => {
        alert(error);
        stopListening();
      }
    );
  };

  const onSubmit = (data: FormData) => {
    mutation.mutate(data);
  };

  return (
    <section className="py-16 bg-card">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-serif font-semibold text-foreground mb-4" data-testid="text-story-form-title">
            Share Your Cultural Story
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto" data-testid="text-story-form-description">
            Help us preserve India's rich heritage by sharing stories of traditional arts, crafts, and cultural practices from your community
          </p>
        </div>

        <Card className="bg-background border-border shadow-lg">
          <CardHeader>
            <CardTitle className="text-2xl font-serif text-foreground" data-testid="text-form-card-title">
              Tell Your Story
            </CardTitle>
            <CardDescription className="text-muted-foreground" data-testid="text-form-card-description">
              Share details about a traditional art form, cultural practice, or heritage story you'd like to preserve
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                <FormField
                  control={form.control}
                  name="name"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-foreground font-medium">Your Name *</FormLabel>
                      <FormControl>
                        <Input
                          {...field}
                          placeholder="Enter your full name"
                          className="bg-input border-border focus:ring-2 focus:ring-ring focus:border-transparent"
                          data-testid="input-story-name"
                        />
                      </FormControl>
                      <FormMessage className="text-destructive text-sm" />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="title"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-foreground font-medium">Title of Tradition/Art *</FormLabel>
                      <FormControl>
                        <Input
                          {...field}
                          placeholder="e.g., Warli Folk Art, Kathak Dance, Block Printing"
                          className="bg-input border-border focus:ring-2 focus:ring-ring focus:border-transparent"
                          data-testid="input-story-title"
                        />
                      </FormControl>
                      <FormMessage className="text-destructive text-sm" />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="description"
                  render={({ field }) => (
                    <FormItem>
                      <div className="flex items-center justify-between">
                        <FormLabel className="text-foreground font-medium">Description *</FormLabel>
                        <Button
                          type="button"
                          variant="outline"
                          size="sm"
                          onClick={handleVoiceInput}
                          className={`ml-2 border-border hover:bg-muted ${
                            isListening 
                              ? "bg-primary text-primary-foreground hover:bg-primary/90" 
                              : "bg-background text-foreground"
                          }`}
                          data-testid="button-voice-input"
                        >
                          {isListening ? (
                            <>
                              <MicOff className="w-4 h-4 mr-2" />
                              Stop Voice Input
                            </>
                          ) : (
                            <>
                              <Mic className="w-4 h-4 mr-2" />
                              Start Voice Input (Hindi)
                            </>
                          )}
                        </Button>
                      </div>
                      <FormControl>
                        <div className="relative">
                          <Textarea
                            {...field}
                            placeholder="Tell us about the tradition, its history, cultural significance, techniques used, or personal experiences with this art form... Or click 'Start Voice Input' to speak in Hindi."
                            className="bg-input border-border focus:ring-2 focus:ring-ring focus:border-transparent min-h-32 resize-none"
                            data-testid="textarea-story-description"
                          />
                          {isListening && (
                            <div className="absolute top-2 right-2">
                              <div className="flex items-center space-x-2 bg-primary/10 text-primary px-3 py-1 rounded-full text-sm">
                                <div className="w-2 h-2 bg-primary rounded-full animate-pulse"></div>
                                <span>सुन रहा है...</span>
                              </div>
                            </div>
                          )}
                        </div>
                      </FormControl>
                      <FormMessage className="text-destructive text-sm" />
                      {isSupported === false && (
                        <p className="text-sm text-muted-foreground mt-1">
                          Voice input is not supported in this browser. Please use Chrome or Edge for voice features.
                        </p>
                      )}
                    </FormItem>
                  )}
                />

                <div className="flex justify-end pt-4">
                  <Button
                    type="submit"
                    disabled={mutation.isPending}
                    className="px-8 py-3 bg-primary text-primary-foreground font-semibold hover:bg-primary/90 transition-colors disabled:opacity-50"
                    data-testid="button-submit-story"
                  >
                    {mutation.isPending ? "Submitting..." : "Submit Story"}
                  </Button>
                </div>
              </form>
            </Form>
          </CardContent>
        </Card>
      </div>
    </section>
  );
}