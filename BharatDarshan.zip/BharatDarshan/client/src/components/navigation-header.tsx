import { useState } from "react";
import { Search, Menu, X } from "lucide-react";
import { useLanguage } from "@/contexts/language-context";
import LanguageSelector from "@/components/language-selector";

export default function NavigationHeader() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const { t } = useLanguage();

  return (
    <nav className="fixed top-0 w-full z-50 bg-background/95 backdrop-blur-md border-b border-border">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 heritage-gradient rounded-lg flex items-center justify-center">
              <svg className="w-6 h-6 text-background" viewBox="0 0 24 24" fill="currentColor">
                <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/>
              </svg>
            </div>
            <h1 className="text-xl font-serif font-semibold text-primary" data-testid="text-site-title">Heritage Gallery</h1>
          </div>
          
          <div className="hidden md:flex items-center space-x-8">
            <a href="#gallery" className="text-foreground hover:text-primary transition-colors" data-testid="link-gallery">{t("nav.gallery")}</a>
            <a href="#collections" className="text-foreground hover:text-primary transition-colors" data-testid="link-collections">{t("nav.collections")}</a>
            <a href="#timeline" className="text-foreground hover:text-primary transition-colors" data-testid="link-timeline">{t("nav.timeline")}</a>
            <a href="#about" className="text-foreground hover:text-primary transition-colors" data-testid="link-about">{t("nav.about")}</a>
          </div>
          
          <div className="flex items-center space-x-4">
            <LanguageSelector />
            <button className="p-2 hover:bg-muted rounded-lg transition-colors" data-testid="button-search">
              <Search className="w-5 h-5 text-muted-foreground" />
            </button>
            <button 
              className="md:hidden p-2 hover:bg-muted rounded-lg transition-colors"
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              data-testid="button-menu"
            >
              {isMenuOpen ? <X className="w-5 h-5 text-muted-foreground" /> : <Menu className="w-5 h-5 text-muted-foreground" />}
            </button>
          </div>
        </div>

        {/* Mobile menu */}
        {isMenuOpen && (
          <div className="md:hidden border-t border-border bg-background">
            <div className="px-2 pt-2 pb-3 space-y-1">
              <a href="#gallery" className="block px-3 py-2 text-foreground hover:text-primary transition-colors" data-testid="link-mobile-gallery">{t("nav.gallery")}</a>
              <a href="#collections" className="block px-3 py-2 text-foreground hover:text-primary transition-colors" data-testid="link-mobile-collections">{t("nav.collections")}</a>
              <a href="#timeline" className="block px-3 py-2 text-foreground hover:text-primary transition-colors" data-testid="link-mobile-timeline">{t("nav.timeline")}</a>
              <a href="#about" className="block px-3 py-2 text-foreground hover:text-primary transition-colors" data-testid="link-mobile-about">{t("nav.about")}</a>
            </div>
          </div>
        )}
      </div>
    </nav>
  );
}
