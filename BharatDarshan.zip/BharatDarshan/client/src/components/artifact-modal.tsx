import { X } from "lucide-react";
import type { Artifact } from "@shared/schema";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";

interface ArtifactModalProps {
  artifact: Artifact;
  onClose: () => void;
}

export default function ArtifactModal({ artifact, onClose }: ArtifactModalProps) {
  return (
    <Dialog open={true} onOpenChange={() => onClose()}>
      <DialogContent className="max-w-4xl max-h-screen overflow-auto bg-card border-border" data-testid="modal-artifact-details">
        <DialogHeader>
          <div className="flex justify-between items-start">
            <DialogTitle className="text-2xl font-serif font-semibold text-foreground" data-testid="text-modal-title">
              Artwork Details
            </DialogTitle>
            <button 
              onClick={onClose}
              className="text-muted-foreground hover:text-foreground transition-colors"
              data-testid="button-close-modal"
            >
              <X className="w-6 h-6" />
            </button>
          </div>
        </DialogHeader>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mt-6">
          <div>
            <img 
              src={artifact.imageUrl} 
              alt={artifact.title}
              className="w-full h-80 object-cover rounded-lg"
              data-testid="img-modal-artifact"
            />
          </div>
          
          <div className="space-y-4">
            <h3 className="text-xl font-serif font-semibold text-foreground" data-testid="text-modal-artifact-title">
              {artifact.title}
            </h3>
            <p className="text-muted-foreground" data-testid="text-modal-artifact-description">
              {artifact.description}
            </p>
            
            <div className="grid grid-cols-2 gap-4">
              {artifact.artist && (
                <div>
                  <h4 className="font-semibold text-foreground">Artist</h4>
                  <p className="text-muted-foreground" data-testid="text-modal-artist">{artifact.artist}</p>
                </div>
              )}
              <div>
                <h4 className="font-semibold text-foreground">Period</h4>
                <p className="text-muted-foreground" data-testid="text-modal-period">{artifact.period}</p>
              </div>
              {artifact.medium && (
                <div>
                  <h4 className="font-semibold text-foreground">Medium</h4>
                  <p className="text-muted-foreground" data-testid="text-modal-medium">{artifact.medium}</p>
                </div>
              )}
              {artifact.dimensions && (
                <div>
                  <h4 className="font-semibold text-foreground">Dimensions</h4>
                  <p className="text-muted-foreground" data-testid="text-modal-dimensions">{artifact.dimensions}</p>
                </div>
              )}
              <div>
                <h4 className="font-semibold text-foreground">Region</h4>
                <p className="text-muted-foreground" data-testid="text-modal-region">{artifact.region}</p>
              </div>
              {artifact.school && (
                <div>
                  <h4 className="font-semibold text-foreground">School</h4>
                  <p className="text-muted-foreground" data-testid="text-modal-school">{artifact.school}</p>
                </div>
              )}
            </div>
            
            {artifact.culturalSignificance && (
              <div>
                <h4 className="font-semibold text-foreground mb-2">Cultural Significance</h4>
                <p className="text-muted-foreground text-sm" data-testid="text-modal-cultural-significance">
                  {artifact.culturalSignificance}
                </p>
              </div>
            )}
            
            {artifact.historicalContext && (
              <div>
                <h4 className="font-semibold text-foreground mb-2">Historical Context</h4>
                <p className="text-muted-foreground text-sm" data-testid="text-modal-historical-context">
                  {artifact.historicalContext}
                </p>
              </div>
            )}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
