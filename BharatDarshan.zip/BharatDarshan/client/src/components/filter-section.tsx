import { Search } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

interface FilterSectionProps {
  searchQuery: string;
  onSearchChange: (query: string) => void;
  selectedCategory: string;
  onCategoryChange: (category: string) => void;
  selectedRegion: string;
  onRegionChange: (region: string) => void;
  selectedPeriod: string;
  onPeriodChange: (period: string) => void;
}

export default function FilterSection({
  searchQuery,
  onSearchChange,
  selectedCategory,
  onCategoryChange,
  selectedRegion,
  onRegionChange,
  selectedPeriod,
  onPeriodChange
}: FilterSectionProps) {

  const categories = [
    { value: "all", label: "All" },
    { value: "paintings", label: "Paintings" },
    { value: "sculptures", label: "Sculptures" },
    { value: "textiles", label: "Textiles" },
    { value: "monuments", label: "Monuments" }
  ];

  return (
    <section className="py-12 bg-card">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-6">
          <div>
            <h2 className="text-3xl font-serif font-semibold text-foreground mb-2" data-testid="text-collections-title">Art Collections</h2>
            <p className="text-muted-foreground" data-testid="text-collections-subtitle">Browse through our curated selection of Indian heritage</p>
          </div>
          
          <div className="flex flex-wrap gap-4">
            {categories.map((category) => (
              <button
                key={category.value}
                onClick={() => onCategoryChange(category.value)}
                className={`px-6 py-2 rounded-full font-medium transition-colors ${
                  selectedCategory === category.value
                    ? "bg-primary text-primary-foreground"
                    : "bg-muted text-muted-foreground hover:bg-primary hover:text-primary-foreground"
                }`}
                data-testid={`button-category-${category.value}`}
              >
                {category.label}
              </button>
            ))}
          </div>
        </div>
        
        <div className="mt-8 flex flex-col sm:flex-row gap-4">
          <div className="flex-1 relative">
            <Input
              type="text"
              placeholder="Search artworks, artists, or periods..."
              value={searchQuery}
              onChange={(e) => onSearchChange(e.target.value)}
              className="w-full pl-12 bg-background border-border focus:ring-2 focus:ring-ring focus:border-transparent"
              data-testid="input-search"
            />
            <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          </div>
          
          <Select value={selectedRegion} onValueChange={onRegionChange}>
            <SelectTrigger className="w-full sm:w-48 bg-background border-border" data-testid="select-region">
              <SelectValue placeholder="All Regions" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Regions</SelectItem>
              <SelectItem value="north">North India</SelectItem>
              <SelectItem value="south">South India</SelectItem>
              <SelectItem value="east">East India</SelectItem>
              <SelectItem value="west">West India</SelectItem>
              <SelectItem value="rajasthan">Rajasthan</SelectItem>
              <SelectItem value="tamil nadu">Tamil Nadu</SelectItem>
              <SelectItem value="kashmir">Kashmir</SelectItem>
              <SelectItem value="maharashtra">Maharashtra</SelectItem>
              <SelectItem value="karnataka">Karnataka</SelectItem>
              <SelectItem value="gujarat">Gujarat</SelectItem>
            </SelectContent>
          </Select>
          
          <Select value={selectedPeriod} onValueChange={onPeriodChange}>
            <SelectTrigger className="w-full sm:w-48 bg-background border-border" data-testid="select-period">
              <SelectValue placeholder="All Periods" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Periods</SelectItem>
              <SelectItem value="ancient">Ancient (3000 BCE - 600 CE)</SelectItem>
              <SelectItem value="classical">Classical (600 - 1200 CE)</SelectItem>
              <SelectItem value="medieval">Medieval (1200 - 1700 CE)</SelectItem>
              <SelectItem value="modern">Modern (1700 CE - Present)</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>
    </section>
  );
}
