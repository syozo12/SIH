export default function CulturalTimeline() {
  const timelineEvents = [
    {
      period: "3300-1300 BCE",
      title: "Indus Valley Civilization",
      description: "Advanced urban planning, pottery, and bronze work",
      color: "primary"
    },
    {
      period: "600-1200 CE", 
      title: "Classical Period",
      description: "Temple architecture, classical dance, and sculpture flourish",
      color: "secondary"
    },
    {
      period: "1526-1857 CE",
      title: "Mughal Era", 
      description: "Miniature paintings, architecture, and decorative arts",
      color: "accent"
    }
  ];

  return (
    <section id="timeline" className="py-16 bg-card">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h2 className="text-4xl font-serif font-semibold text-center text-foreground mb-12" data-testid="text-timeline-title">
          Cultural Timeline
        </h2>
        
        <div className="relative">
          {/* Timeline line */}
          <div className="absolute left-1/2 transform -translate-x-px h-full w-0.5 bg-primary"></div>
          
          {/* Timeline items */}
          <div className="space-y-12">
            {timelineEvents.map((event, index) => (
              <div key={index} className="relative flex items-center" data-testid={`timeline-event-${index}`}>
                {index % 2 === 0 ? (
                  <>
                    <div className="flex-1 pr-8 text-right">
                      <h3 className="text-xl font-serif font-semibold text-foreground mb-2" data-testid={`text-timeline-title-${index}`}>
                        {event.title}
                      </h3>
                      <p className="text-muted-foreground" data-testid={`text-timeline-description-${index}`}>
                        {event.description}
                      </p>
                    </div>
                    <div className={`relative flex items-center justify-center w-4 h-4 bg-${event.color} rounded-full`}></div>
                    <div className="flex-1 pl-8">
                      <span className={`text-2xl font-bold text-${event.color}`} data-testid={`text-timeline-period-${index}`}>
                        {event.period}
                      </span>
                    </div>
                  </>
                ) : (
                  <>
                    <div className="flex-1 pr-8 text-right">
                      <span className={`text-2xl font-bold text-${event.color}`} data-testid={`text-timeline-period-${index}`}>
                        {event.period}
                      </span>
                    </div>
                    <div className={`relative flex items-center justify-center w-4 h-4 bg-${event.color} rounded-full`}></div>
                    <div className="flex-1 pl-8">
                      <h3 className="text-xl font-serif font-semibold text-foreground mb-2" data-testid={`text-timeline-title-${index}`}>
                        {event.title}
                      </h3>
                      <p className="text-muted-foreground" data-testid={`text-timeline-description-${index}`}>
                        {event.description}
                      </p>
                    </div>
                  </>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
