import { ArrowRight } from "lucide-react";

export default function FeaturedCollection() {
  return (
    <section className="py-16 bg-background">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-serif font-semibold text-foreground mb-4" data-testid="text-featured-title">
            Featured Collection
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto" data-testid="text-featured-description">
            Explore the masterpieces of Indian artistry, from ancient temple sculptures to vibrant regional paintings
          </p>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div>
            <img 
              src="https://pixabay.com/get/gf8417bb7124c6bcf692ae6ce0a24e2c25ea17c3a9375f4ee16e111a74c3fd3b9bc1b05cc1791688b28d9b10f353b39e12c4c6f4b4e02adaeaa84c5ce56f3789a_1280.jpg" 
              alt="Traditional Indian miniature painting of royal court" 
              className="w-full h-96 object-cover rounded-xl shadow-2xl"
              data-testid="img-featured-artwork"
            />
          </div>
          
          <div className="space-y-6">
            <div className="inline-block px-4 py-2 bg-primary/10 text-primary rounded-full text-sm font-medium" data-testid="badge-featured">
              Featured Artwork
            </div>
            <h3 className="text-3xl font-serif font-semibold text-foreground" data-testid="text-featured-artwork-title">
              Rajput Court Painting
            </h3>
            <p className="text-lg text-muted-foreground leading-relaxed" data-testid="text-featured-artwork-description">
              This exquisite 18th-century Rajput painting depicts a royal court scene with intricate details showcasing the opulent lifestyle of Indian royalty. The use of vibrant colors and gold leaf demonstrates the sophisticated artistic techniques of the era.
            </p>
            
            <div className="grid grid-cols-2 gap-4">
              <div>
                <h4 className="font-semibold text-foreground mb-2">Period</h4>
                <p className="text-muted-foreground" data-testid="text-featured-period">18th Century</p>
              </div>
              <div>
                <h4 className="font-semibold text-foreground mb-2">Origin</h4>
                <p className="text-muted-foreground" data-testid="text-featured-origin">Rajasthan</p>
              </div>
              <div>
                <h4 className="font-semibold text-foreground mb-2">Medium</h4>
                <p className="text-muted-foreground" data-testid="text-featured-medium">Pigment on Paper</p>
              </div>
              <div>
                <h4 className="font-semibold text-foreground mb-2">School</h4>
                <p className="text-muted-foreground" data-testid="text-featured-school">Rajput</p>
              </div>
            </div>
            
            <button className="inline-flex items-center px-6 py-3 bg-primary text-primary-foreground font-semibold rounded-lg hover:bg-primary/90 transition-colors" data-testid="button-view-details">
              View Details
              <ArrowRight className="ml-2 w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}
