import { Calendar, MapPin, Clock } from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { useLanguage } from "@/contexts/language-context";

interface Event {
  id: string;
  name: string;
  date: string;
  time: string;
  location: string;
  type: "festival" | "workshop" | "exhibition";
  description: string;
}

export default function EventCalendar() {
  const { t } = useLanguage();
  // Sample events - can be easily updated
  const events: Event[] = [
    {
      id: "1",
      name: "Diwali Festival Celebration",
      date: "2024-11-12",
      time: "6:00 PM - 10:00 PM",
      location: "Community Cultural Center, Delhi",
      type: "festival",
      description: "Traditional Diwali celebration with rangoli, diyas, and cultural performances"
    },
    {
      id: "2", 
      name: "Madhubani Painting Workshop",
      date: "2024-11-18",
      time: "2:00 PM - 5:00 PM",
      location: "Art Gallery, Mumbai",
      type: "workshop",
      description: "Learn traditional Madhubani painting techniques from Bihar"
    },
    {
      id: "3",
      name: "Classical Dance Performance",
      date: "2024-11-25",
      time: "7:00 PM - 9:00 PM", 
      location: "Kalakshetra, Chennai",
      type: "exhibition",
      description: "Bharatanatyam and Odissi performances by renowned artists"
    },
    {
      id: "4",
      name: "Karva Chauth Celebration",
      date: "2024-11-01",
      time: "5:00 PM - 8:00 PM",
      location: "Temple Complex, Jaipur",
      type: "festival", 
      description: "Traditional festival celebration with prayers and cultural activities"
    },
    {
      id: "5",
      name: "Block Printing Workshop",
      date: "2024-12-05",
      time: "10:00 AM - 4:00 PM",
      location: "Craft Center, Jodhpur",
      type: "workshop",
      description: "Hands-on workshop on traditional Rajasthani block printing techniques"
    },
    {
      id: "6",
      name: "Heritage Art Exhibition",
      date: "2024-12-15",
      time: "11:00 AM - 7:00 PM",
      location: "National Museum, New Delhi",
      type: "exhibition",
      description: "Special exhibition showcasing 500 years of Indian miniature paintings"
    }
  ];

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString("en-IN", {
      weekday: "short",
      month: "short", 
      day: "numeric"
    });
  };

  const getEventTypeColor = (type: string) => {
    switch (type) {
      case "festival":
        return "bg-accent text-accent-foreground";
      case "workshop": 
        return "bg-primary text-primary-foreground";
      case "exhibition":
        return "bg-secondary text-secondary-foreground";
      default:
        return "bg-muted text-muted-foreground";
    }
  };

  // Sort events by date
  const sortedEvents = events.sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());

  return (
    <section className="py-16 bg-background">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-serif font-semibold text-foreground mb-4" data-testid="text-events-title">
            {t("events.title")}
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto" data-testid="text-events-description">
            {t("events.description")}
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {sortedEvents.map((event) => (
            <Card key={event.id} className="bg-card border-border hover:shadow-lg transition-shadow" data-testid={`card-event-${event.id}`}>
              <CardHeader className="pb-3">
                <div className="flex justify-between items-start mb-2">
                  <div className={`px-3 py-1 rounded-full text-sm font-medium ${getEventTypeColor(event.type)}`}>
                    {event.type.charAt(0).toUpperCase() + event.type.slice(1)}
                  </div>
                  <div className="text-right text-muted-foreground">
                    <div className="font-semibold text-foreground" data-testid={`text-date-${event.id}`}>
                      {formatDate(event.date)}
                    </div>
                  </div>
                </div>
                <CardTitle className="text-xl font-serif text-foreground" data-testid={`text-event-name-${event.id}`}>
                  {event.name}
                </CardTitle>
                <CardDescription className="text-muted-foreground" data-testid={`text-event-description-${event.id}`}>
                  {event.description}
                </CardDescription>
              </CardHeader>
              <CardContent className="pt-0">
                <div className="space-y-2">
                  <div className="flex items-center text-sm text-muted-foreground">
                    <Clock className="w-4 h-4 mr-2 flex-shrink-0" />
                    <span data-testid={`text-time-${event.id}`}>{event.time}</span>
                  </div>
                  <div className="flex items-start text-sm text-muted-foreground">
                    <MapPin className="w-4 h-4 mr-2 flex-shrink-0 mt-0.5" />
                    <span data-testid={`text-location-${event.id}`}>{event.location}</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="mt-12 text-center">
          <button 
            className="px-8 py-3 border border-border text-foreground hover:bg-muted transition-colors rounded-lg"
            data-testid="button-view-all-events"
          >
            {t("events.viewAll")}
          </button>
        </div>
      </div>
    </section>
  );
}