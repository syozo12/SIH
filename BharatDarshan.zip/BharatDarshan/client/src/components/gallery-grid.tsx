import { useQuery } from "@tanstack/react-query";
import { useEffect, useState } from "react";
import type { Artifact } from "@shared/schema";
import { Card } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";

interface GalleryGridProps {
  searchQuery: string;
  selectedCategory: string;
  selectedRegion: string;
  selectedPeriod: string;
  onArtifactClick: (artifact: Artifact) => void;
}

export default function GalleryGrid({
  searchQuery,
  selectedCategory,
  selectedRegion,
  selectedPeriod,
  onArtifactClick
}: GalleryGridProps) {
  const [filteredArtifacts, setFilteredArtifacts] = useState<Artifact[]>([]);

  const { data: artifacts, isLoading } = useQuery<Artifact[]>({
    queryKey: ["/api/artifacts"],
  });

  useEffect(() => {
    if (!artifacts) return;

    let filtered = artifacts;

    // Apply search filter
    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      filtered = filtered.filter(artifact =>
        artifact.title.toLowerCase().includes(query) ||
        artifact.description.toLowerCase().includes(query) ||
        artifact.artist?.toLowerCase().includes(query) ||
        artifact.region.toLowerCase().includes(query) ||
        artifact.period.toLowerCase().includes(query) ||
        artifact.school?.toLowerCase().includes(query)
      );
    }

    // Apply category filter
    if (selectedCategory !== "all") {
      filtered = filtered.filter(artifact => artifact.category === selectedCategory);
    }

    // Apply region filter
    if (selectedRegion !== "all") {
      filtered = filtered.filter(artifact => 
        artifact.region.toLowerCase().includes(selectedRegion.toLowerCase())
      );
    }

    // Apply period filter
    if (selectedPeriod !== "all") {
      const periodMapping: Record<string, (artifact: Artifact) => boolean> = {
        ancient: (artifact) => {
          const year = artifact.yearCreated;
          return !year || year <= 600;
        },
        classical: (artifact) => {
          const year = artifact.yearCreated;
          return year ? year > 600 && year <= 1200 : false;
        },
        medieval: (artifact) => {
          const year = artifact.yearCreated;
          return year ? year > 1200 && year <= 1700 : false;
        },
        modern: (artifact) => {
          const year = artifact.yearCreated;
          return year ? year > 1700 : false;
        }
      };

      if (periodMapping[selectedPeriod]) {
        filtered = filtered.filter(periodMapping[selectedPeriod]);
      }
    }

    setFilteredArtifacts(filtered);
  }, [artifacts, searchQuery, selectedCategory, selectedRegion, selectedPeriod]);

  if (isLoading) {
    return (
      <section id="gallery" className="py-16 bg-background">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {Array.from({ length: 8 }).map((_, i) => (
              <Card key={i} className="overflow-hidden">
                <Skeleton className="w-full h-64" />
                <div className="p-4 space-y-2">
                  <Skeleton className="h-4 w-3/4" />
                  <Skeleton className="h-3 w-1/2" />
                  <Skeleton className="h-3 w-1/3" />
                </div>
              </Card>
            ))}
          </div>
        </div>
      </section>
    );
  }

  return (
    <section id="gallery" className="py-16 bg-background">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {filteredArtifacts.length === 0 ? (
          <div className="text-center py-12">
            <h3 className="text-2xl font-serif font-semibold text-foreground mb-4" data-testid="text-no-results">No artifacts found</h3>
            <p className="text-muted-foreground" data-testid="text-no-results-description">Try adjusting your search criteria or filters</p>
          </div>
        ) : (
          <>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {filteredArtifacts.map((artifact) => (
                <Card
                  key={artifact.id}
                  className="gallery-item bg-card rounded-lg overflow-hidden cursor-pointer"
                  onClick={() => onArtifactClick(artifact)}
                  data-testid={`card-artifact-${artifact.id}`}
                >
                  <img 
                    src={artifact.imageUrl} 
                    alt={artifact.title}
                    className="w-full h-64 object-cover"
                    data-testid={`img-artifact-${artifact.id}`}
                  />
                  <div className="p-4">
                    <h3 className="font-serif font-semibold text-lg text-foreground mb-1" data-testid={`text-title-${artifact.id}`}>
                      {artifact.title}
                    </h3>
                    <p className="text-muted-foreground text-sm mb-2" data-testid={`text-period-${artifact.id}`}>
                      {artifact.period}
                    </p>
                    <p className="text-muted-foreground text-sm" data-testid={`text-region-${artifact.id}`}>
                      {artifact.region}
                    </p>
                  </div>
                </Card>
              ))}
            </div>
            
            <div className="mt-12 text-center">
              <button 
                className="px-8 py-3 border border-border text-foreground hover:bg-muted transition-colors rounded-lg"
                data-testid="button-load-more"
              >
                Load More Artifacts
              </button>
            </div>
          </>
        )}
      </div>
    </section>
  );
}
