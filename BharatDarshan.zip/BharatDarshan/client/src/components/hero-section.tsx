import { useLanguage } from "@/contexts/language-context";

export default function HeroSection() {
  const { t } = useLanguage();
  return (
    <section className="relative pt-16 min-h-screen flex items-center">
      {/* Background image */}
      <div className="absolute inset-0 bg-cover bg-center" style={{backgroundImage: "url('https://images.unsplash.com/photo-1564507592333-c60657eea523?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&h=1080')"}}>
        <div className="absolute inset-0 bg-gradient-to-r from-heritage-dark/90 via-heritage-dark/70 to-transparent"></div>
        <div className="absolute inset-0 pattern-overlay"></div>
      </div>
      
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-3xl">
          <h1 className="text-5xl md:text-7xl font-serif font-bold text-foreground mb-6 leading-tight" data-testid="text-hero-title">
            {t("hero.title1")}
            <span className="text-transparent bg-clip-text heritage-gradient block">{t("hero.title2")}</span>
          </h1>
          <p className="text-xl text-muted-foreground mb-8 leading-relaxed" data-testid="text-hero-description">
            {t("hero.description")}
          </p>
          <div className="flex flex-col sm:flex-row gap-4">
            <button 
              className="px-8 py-4 bg-primary text-primary-foreground font-semibold rounded-lg hover:bg-primary/90 transition-colors"
              onClick={() => document.getElementById('gallery')?.scrollIntoView({ behavior: 'smooth' })}
              data-testid="button-explore-gallery"
            >
              {t("hero.exploreGallery")}
            </button>
            <button 
              className="px-8 py-4 border border-border text-foreground hover:bg-muted transition-colors rounded-lg"
              onClick={() => document.getElementById('timeline')?.scrollIntoView({ behavior: 'smooth' })}
              data-testid="button-cultural-timeline"
            >
              {t("hero.culturalTimeline")}
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}
