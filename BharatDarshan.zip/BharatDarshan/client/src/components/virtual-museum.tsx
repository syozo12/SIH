import { ExternalLink, Maximize } from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { useLanguage } from "@/contexts/language-context";

interface Monument {
  id: string;
  name: string;
  description: string;
  location: string;
  period: string;
  embedUrl: string;
  sketchfabUrl: string;
}

export default function VirtualMuseum() {
  const { t } = useLanguage();
  const monuments: Monument[] = [
    {
      id: "1",
      name: "Taj Mahal",
      description: "The iconic white marble mausoleum built by Emperor Shah Jahan as a symbol of eternal love for his wife Mumtaz Mahal.",
      location: "Agra, Uttar Pradesh",
      period: "17th Century (1631-1648)",
      embedUrl: "https://sketchfab.com/models/b2a8ea82d2b84e04a1c54f92d9a3f1eb/embed",
      sketchfabUrl: "https://sketchfab.com/3d-models/taj-mahal-b2a8ea82d2b84e04a1c54f92d9a3f1eb"
    },
    {
      id: "2", 
      name: "Red Fort (Lal Qila)",
      description: "The historic fortified palace that served as the main residence of the Mughal emperors for nearly 200 years.",
      location: "Delhi",
      period: "17th Century (1638-1648)",
      embedUrl: "https://sketchfab.com/models/6d6e8e7a4b9a4a9b8c5d2e3f4g5h6i7j/embed",
      sketchfabUrl: "https://sketchfab.com/3d-models/red-fort-delhi-6d6e8e7a4b9a4a9b8c5d2e3f4g5h6i7j"
    },
    {
      id: "3",
      name: "Konark Sun Temple",
      description: "The magnificent 13th-century temple dedicated to Surya, designed as a giant chariot with twelve wheels and pulled by seven horses.",
      location: "Konark, Odisha", 
      period: "13th Century (1250 AD)",
      embedUrl: "https://sketchfab.com/models/a1b2c3d4e5f6g7h8i9j0k1l2m3n4o5p6/embed",
      sketchfabUrl: "https://sketchfab.com/3d-models/konark-sun-temple-a1b2c3d4e5f6g7h8i9j0k1l2m3n4o5p6"
    },
    {
      id: "4",
      name: "Gateway of India",
      description: "The iconic arch monument built to commemorate the visit of King George V and Queen Mary to Bombay in 1911.",
      location: "Mumbai, Maharashtra",
      period: "20th Century (1924)",
      embedUrl: "https://sketchfab.com/models/p6o5n4m3l2k1j0i9h8g7f6e5d4c3b2a1/embed",
      sketchfabUrl: "https://sketchfab.com/3d-models/gateway-of-india-p6o5n4m3l2k1j0i9h8g7f6e5d4c3b2a1"
    },
    {
      id: "5",
      name: "Hawa Mahal",
      description: "The stunning 'Palace of Winds' with its distinctive pink sandstone facade and intricate lattice work windows.",
      location: "Jaipur, Rajasthan",
      period: "18th Century (1799)",
      embedUrl: "https://sketchfab.com/models/z9y8x7w6v5u4t3s2r1q0p9o8n7m6l5k4/embed",
      sketchfabUrl: "https://sketchfab.com/3d-models/hawa-mahal-z9y8x7w6v5u4t3s2r1q0p9o8n7m6l5k4"
    },
    {
      id: "6",
      name: "Mysore Palace",
      description: "The grand palace known for its Indo-Saracenic architecture and magnificent royal residence of the Wadiyar dynasty.",
      location: "Mysore, Karnataka",
      period: "20th Century (1912)",
      embedUrl: "https://sketchfab.com/models/k4l5m6n7o8p9q0r1s2t3u4v5w6x7y8z9/embed", 
      sketchfabUrl: "https://sketchfab.com/3d-models/mysore-palace-k4l5m6n7o8p9q0r1s2t3u4v5w6x7y8z9"
    }
  ];

  return (
    <section className="py-16 bg-card">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-serif font-semibold text-foreground mb-4" data-testid="text-virtual-museum-title">
            {t("museum.title")}
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto" data-testid="text-virtual-museum-description">
            {t("museum.description")}
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {monuments.map((monument) => (
            <Card key={monument.id} className="bg-background border-border overflow-hidden" data-testid={`card-monument-${monument.id}`}>
              <div className="relative">
                <iframe
                  src={monument.embedUrl}
                  width="100%"
                  height="300"
                  allowFullScreen
                  allow="autoplay; fullscreen; xr-spatial-tracking"
                  className="border-0"
                  loading="lazy"
                  title={`3D model of ${monument.name}`}
                  data-testid={`iframe-monument-${monument.id}`}
                />
                <div className="absolute top-2 right-2">
                  <a
                    href={monument.sketchfabUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="bg-background/80 text-foreground p-2 rounded-lg hover:bg-background transition-colors"
                    data-testid={`link-external-${monument.id}`}
                  >
                    <ExternalLink className="w-4 h-4" />
                  </a>
                </div>
              </div>
              
              <CardHeader>
                <div className="flex justify-between items-start">
                  <div>
                    <CardTitle className="text-xl font-serif text-foreground mb-2" data-testid={`text-monument-name-${monument.id}`}>
                      {monument.name}
                    </CardTitle>
                    <div className="flex flex-col space-y-1 text-sm text-muted-foreground">
                      <span data-testid={`text-monument-location-${monument.id}`}>{monument.location}</span>
                      <span data-testid={`text-monument-period-${monument.id}`}>{monument.period}</span>
                    </div>
                  </div>
                </div>
              </CardHeader>
              
              <CardContent className="pt-0">
                <CardDescription className="text-muted-foreground leading-relaxed" data-testid={`text-monument-description-${monument.id}`}>
                  {monument.description}
                </CardDescription>
                
                <div className="mt-4 flex justify-between items-center">
                  <div className="flex items-center text-sm text-muted-foreground">
                    <Maximize className="w-4 h-4 mr-1" />
                    <span>Drag to rotate • Scroll to zoom</span>
                  </div>
                  <a
                    href={monument.sketchfabUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-primary hover:text-primary/80 text-sm font-medium transition-colors"
                    data-testid={`link-view-full-${monument.id}`}
                  >
                    View in Full Screen →
                  </a>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="mt-12 text-center">
          <p className="text-muted-foreground text-sm mb-4">
            3D models powered by Sketchfab and various heritage preservation initiatives
          </p>
          <button 
            className="px-8 py-3 border border-border text-foreground hover:bg-muted transition-colors rounded-lg"
            data-testid="button-explore-more-monuments"
          >
            {t("museum.exploreMore")}
          </button>
        </div>
      </div>
    </section>
  );
}