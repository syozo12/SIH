import NavigationHeader from "@/components/navigation-header";
import HeroSection from "@/components/hero-section";
import FilterSection from "@/components/filter-section";
import GalleryGrid from "@/components/gallery-grid";
import CulturalTimeline from "@/components/cultural-timeline";
import FeaturedCollection from "@/components/featured-collection";
import EventCalendar from "@/components/event-calendar";
import VirtualMuseum from "@/components/virtual-museum";
import StorySubmissionForm from "@/components/story-submission-form";
import Footer from "@/components/footer";
import ArtifactModal from "@/components/artifact-modal";
import { useState } from "react";
import type { Artifact } from "@shared/schema";

export default function Home() {
  const [selectedArtifact, setSelectedArtifact] = useState<Artifact | null>(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [selectedRegion, setSelectedRegion] = useState("all");
  const [selectedPeriod, setSelectedPeriod] = useState("all");

  return (
    <div className="min-h-screen bg-background">
      <NavigationHeader />
      <HeroSection />
      <FilterSection 
        searchQuery={searchQuery}
        onSearchChange={setSearchQuery}
        selectedCategory={selectedCategory}
        onCategoryChange={setSelectedCategory}
        selectedRegion={selectedRegion}
        onRegionChange={setSelectedRegion}
        selectedPeriod={selectedPeriod}
        onPeriodChange={setSelectedPeriod}
      />
      <GalleryGrid 
        searchQuery={searchQuery}
        selectedCategory={selectedCategory}
        selectedRegion={selectedRegion}
        selectedPeriod={selectedPeriod}
        onArtifactClick={setSelectedArtifact}
      />
      <CulturalTimeline />
      <FeaturedCollection />
      <EventCalendar />
      <VirtualMuseum />
      <StorySubmissionForm />
      <Footer />
      
      {selectedArtifact && (
        <ArtifactModal 
          artifact={selectedArtifact}
          onClose={() => setSelectedArtifact(null)}
        />
      )}
    </div>
  );
}
