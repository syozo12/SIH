import { createContext, useContext, useState, ReactNode } from "react";

export type Language = "en" | "hi";

interface Translations {
  [key: string]: {
    en: string;
    hi: string;
  };
}

interface LanguageContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: string) => string;
}

const translations: Translations = {
  // Navigation
  "nav.gallery": { en: "Gallery", hi: "गैलरी" },
  "nav.collections": { en: "Collections", hi: "संग्रह" },
  "nav.timeline": { en: "Timeline", hi: "समयसीमा" },
  "nav.about": { en: "About", hi: "के बारे में" },
  
  // Hero Section
  "hero.title1": { en: "Discover India's", hi: "भारत की खोज करें" },
  "hero.title2": { en: "Cultural Heritage", hi: "सांस्कृतिक विरासत" },
  "hero.description": { 
    en: "Journey through millennia of artistic excellence, from ancient temple sculptures to vibrant traditional paintings that tell the story of our rich cultural tapestry.", 
    hi: "प्राचीन मंदिर मूर्तियों से लेकर जीवंत पारंपरिक चित्रों तक, हमारी समृद्ध सांस्कृतिक विरासत की कहानी कहने वाली कलात्मक उत्कृष्टता की सहस्राब्दियों की यात्रा करें।" 
  },
  "hero.exploreGallery": { en: "Explore Gallery", hi: "गैलरी देखें" },
  "hero.culturalTimeline": { en: "Cultural Timeline", hi: "सांस्कृतिक समयसीमा" },
  
  // Filter Section
  "filter.title": { en: "Art Collections", hi: "कला संग्रह" },
  "filter.subtitle": { en: "Browse through our curated selection of Indian heritage", hi: "भारतीय विरासत के हमारे क्यूरेटेड चयन को देखें" },
  "filter.all": { en: "All", hi: "सभी" },
  "filter.paintings": { en: "Paintings", hi: "चित्रकला" },
  "filter.sculptures": { en: "Sculptures", hi: "मूर्तिकला" },
  "filter.textiles": { en: "Textiles", hi: "वस्त्र" },
  "filter.monuments": { en: "Monuments", hi: "स्मारक" },
  "filter.searchPlaceholder": { en: "Search artworks, artists, or periods...", hi: "कलाकृतियों, कलाकारों या कालों की खोज करें..." },
  
  // Gallery
  "gallery.noResults": { en: "No artifacts found", hi: "कोई कलाकृति नहीं मिली" },
  "gallery.noResultsDesc": { en: "Try adjusting your search criteria or filters", hi: "अपनी खोज मापदंड या फ़िल्टर को समायोजित करने का प्रयास करें" },
  "gallery.loadMore": { en: "Load More Artifacts", hi: "और कलाकृतियां लोड करें" },
  
  // Timeline
  "timeline.title": { en: "Cultural Timeline", hi: "सांस्कृतिक समयसीमा" },
  
  // Featured Collection
  "featured.title": { en: "Featured Collection", hi: "विशेष संग्रह" },
  "featured.description": { 
    en: "Explore the masterpieces of Indian artistry, from ancient temple sculptures to vibrant regional paintings", 
    hi: "प्राचीन मंदिर मूर्तियों से लेकर जीवंत क्षेत्रीय चित्रों तक भारतीय कलाकारी की उत्कृष्ट कृतियों का अन्वेषण करें" 
  },
  "featured.viewDetails": { en: "View Details", hi: "विवरण देखें" },
  
  // Story Submission
  "story.title": { en: "Share Your Cultural Story", hi: "अपनी सांस्कृतिक कहानी साझा करें" },
  "story.description": { 
    en: "Help us preserve India's rich heritage by sharing stories of traditional arts, crafts, and cultural practices from your community", 
    hi: "अपने समुदाय की पारंपरिक कलाओं, शिल्प और सांस्कृतिक प्रथाओं की कहानियों को साझा करके भारत की समृद्ध विरासत को संरक्षित करने में हमारी सहायता करें" 
  },
  "story.formTitle": { en: "Tell Your Story", hi: "अपनी कहानी बताएं" },
  "story.formDescription": { 
    en: "Share details about a traditional art form, cultural practice, or heritage story you'd like to preserve", 
    hi: "किसी पारंपरिक कला रूप, सांस्कृतिक प्रथा या विरासत की कहानी के बारे में विवरण साझा करें जिसे आप संरक्षित करना चाहते हैं" 
  },
  "story.nameLabel": { en: "Your Name *", hi: "आपका नाम *" },
  "story.namePlaceholder": { en: "Enter your full name", hi: "अपना पूरा नाम दर्ज करें" },
  "story.titleLabel": { en: "Title of Tradition/Art *", hi: "परंपरा/कला का शीर्षक *" },
  "story.titlePlaceholder": { en: "e.g., Warli Folk Art, Kathak Dance, Block Printing", hi: "जैसे, वारली लोक कला, कत्थक नृत्य, ब्लॉक प्रिंटिंग" },
  "story.descriptionLabel": { en: "Description *", hi: "विवरण *" },
  "story.descriptionPlaceholder": { 
    en: "Tell us about the tradition, its history, cultural significance, techniques used, or personal experiences with this art form... Or click 'Start Voice Input' to speak in Hindi.", 
    hi: "हमें इस परंपरा के बारे में, इसके इतिहास, सांस्कृतिक महत्व, उपयोग की जाने वाली तकनीकों या इस कला रूप के साथ व्यक्तिगत अनुभवों के बारे में बताएं... या हिंदी में बोलने के लिए 'वॉयस इनपुट शुरू करें' पर क्लिक करें।" 
  },
  "story.voiceStart": { en: "Start Voice Input (Hindi)", hi: "वॉयस इनपुट शुरू करें (हिंदी)" },
  "story.voiceStop": { en: "Stop Voice Input", hi: "वॉयस इनपुट बंद करें" },
  "story.submit": { en: "Submit Story", hi: "कहानी जमा करें" },
  "story.submitting": { en: "Submitting...", hi: "जमा किया जा रहा है..." },
  
  // Events
  "events.title": { en: "Upcoming Cultural Events", hi: "आगामी सांस्कृतिक कार्यक्रम" },
  "events.description": { 
    en: "Join us for festivals, workshops, and exhibitions celebrating India's rich cultural heritage", 
    hi: "भारत की समृद्ध सांस्कृतिक विरासत का जश्न मनाने वाले त्योहारों, कार्यशालाओं और प्रदर्शनियों में हमारे साथ जुड़ें" 
  },
  "events.viewAll": { en: "View All Events", hi: "सभी कार्यक्रम देखें" },
  
  // Virtual Museum
  "museum.title": { en: "Virtual Museum", hi: "आभासी संग्रहालय" },
  "museum.description": { 
    en: "Explore India's magnificent monuments in immersive 3D. Walk around these architectural marvels from the comfort of your home.", 
    hi: "भारत के भव्य स्मारकों को immersive 3D में देखें। अपने घर के आराम से इन वास्तुकला के चमत्कारों के आसपास घूमें।" 
  },
  "museum.exploreMore": { en: "Explore More Monuments", hi: "और स्मारक देखें" },
  "museum.viewFullScreen": { en: "View in Full Screen", hi: "पूर्ण स्क्रीन में देखें" },
  
  // Footer
  "footer.description": { 
    en: "Preserving and showcasing India's rich cultural heritage through digital experiences that connect past and present.", 
    hi: "डिजिटल अनुभवों के माध्यम से भारत की समृद्ध सांस्कृतिक विरासत का संरक्षण और प्रदर्शन जो अतीत और वर्तमान को जोड़ते हैं।" 
  },
  "footer.explore": { en: "Explore", hi: "देखें" },
  "footer.learn": { en: "Learn", hi: "सीखें" },
  "footer.copyright": { en: "© 2024 Heritage Gallery. Preserving culture for future generations.", hi: "© 2024 हेरिटेज गैलरी। भावी पीढ़ियों के लिए संस्कृति का संरक्षण।" }
};

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

interface LanguageProviderProps {
  children: ReactNode;
}

export function LanguageProvider({ children }: LanguageProviderProps) {
  const [language, setLanguage] = useState<Language>("en");

  const t = (key: string): string => {
    const translation = translations[key];
    if (!translation) {
      console.warn(`Translation key "${key}" not found`);
      return key;
    }
    return translation[language] || translation.en || key;
  };

  const value = {
    language,
    setLanguage,
    t
  };

  return (
    <LanguageContext.Provider value={value}>
      {children}
    </LanguageContext.Provider>
  );
}

export function useLanguage(): LanguageContextType {
  const context = useContext(LanguageContext);
  if (!context) {
    throw new Error("useLanguage must be used within a LanguageProvider");
  }
  return context;
}