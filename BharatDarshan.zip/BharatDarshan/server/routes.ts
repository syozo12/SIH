import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertStorySchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  
  // Get all artifacts
  app.get("/api/artifacts", async (req, res) => {
    try {
      const artifacts = await storage.getArtifacts();
      res.json(artifacts);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch artifacts" });
    }
  });

  // Get artifact by ID
  app.get("/api/artifacts/:id", async (req, res) => {
    try {
      const artifact = await storage.getArtifactById(req.params.id);
      if (!artifact) {
        return res.status(404).json({ message: "Artifact not found" });
      }
      res.json(artifact);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch artifact" });
    }
  });

  // Get artifacts by category
  app.get("/api/artifacts/category/:category", async (req, res) => {
    try {
      const artifacts = await storage.getArtifactsByCategory(req.params.category);
      res.json(artifacts);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch artifacts by category" });
    }
  });

  // Get artifacts by region
  app.get("/api/artifacts/region/:region", async (req, res) => {
    try {
      const artifacts = await storage.getArtifactsByRegion(req.params.region);
      res.json(artifacts);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch artifacts by region" });
    }
  });

  // Search artifacts
  app.get("/api/search", async (req, res) => {
    try {
      const query = req.query.q as string;
      if (!query) {
        return res.status(400).json({ message: "Search query is required" });
      }
      
      const artifacts = await storage.searchArtifacts(query);
      res.json(artifacts);
    } catch (error) {
      res.status(500).json({ message: "Failed to search artifacts" });
    }
  });

  // Get all stories
  app.get("/api/stories", async (req, res) => {
    try {
      const stories = await storage.getStories();
      res.json(stories);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch stories" });
    }
  });

  // Create new story
  app.post("/api/stories", async (req, res) => {
    try {
      const validatedData = insertStorySchema.parse(req.body);
      const story = await storage.createStory(validatedData);
      res.status(201).json(story);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Validation failed", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create story" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
