import { type User, type InsertUser, type Artifact, type InsertArtifact, type Story, type InsertStory } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  getArtifacts(): Promise<Artifact[]>;
  getArtifactById(id: string): Promise<Artifact | undefined>;
  getArtifactsByCategory(category: string): Promise<Artifact[]>;
  getArtifactsByRegion(region: string): Promise<Artifact[]>;
  getArtifactsByPeriod(period: string): Promise<Artifact[]>;
  searchArtifacts(query: string): Promise<Artifact[]>;
  createArtifact(artifact: InsertArtifact): Promise<Artifact>;
  getStories(): Promise<Story[]>;
  createStory(story: InsertStory): Promise<Story>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private artifacts: Map<string, Artifact>;
  private stories: Map<string, Story>;

  constructor() {
    this.users = new Map();
    this.artifacts = new Map();
    this.stories = new Map();
    this.initializeArtifacts();
  }

  private initializeArtifacts() {
    const initialArtifacts: InsertArtifact[] = [
      {
        title: "Rajasthani Miniature",
        description: "This exquisite miniature painting depicts a royal court scene with intricate details showcasing the opulent lifestyle of Indian royalty. The use of vibrant colors and gold leaf demonstrates the sophisticated artistic techniques of the era.",
        period: "Mughal Period, 17th Century",
        region: "Rajasthan",
        category: "paintings",
        artist: "Unknown Master",
        medium: "Pigment on Paper",
        dimensions: "25 × 18 cm",
        imageUrl: "https://images.unsplash.com/photo-1578662996442-48f60103fc96?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=1000",
        culturalSignificance: "Represents the synthesis of Persian and Indian artistic traditions during the Mughal era",
        historicalContext: "Created during the height of Mughal influence in Rajasthan",
        school: "Rajput",
        yearCreated: 1650
      },
      {
        title: "Chola Bronze",
        description: "A masterpiece of South Indian bronze sculpture representing the classical period of Indian art. The intricate details and proportions showcase the advanced metallurgy and artistic skills of the Chola dynasty.",
        period: "Classical Period, 11th Century",
        region: "Tamil Nadu",
        category: "sculptures",
        artist: "Chola Artisan",
        medium: "Bronze",
        dimensions: "68 × 45 cm",
        imageUrl: "https://images.unsplash.com/photo-1544735716-392fe2489ffa?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=1000",
        culturalSignificance: "Exemplifies the spiritual and artistic achievements of the Chola period",
        historicalContext: "Created during the reign of Raja Raja Chola I",
        school: "Chola",
        yearCreated: 1010
      },
      {
        title: "Kashmiri Shawl",
        description: "An exquisite example of Kashmiri textile artistry featuring intricate paisley patterns and fine embroidery. The delicate craftsmanship represents centuries of textile tradition.",
        period: "18th Century",
        region: "Kashmir",
        category: "textiles",
        artist: "Kashmiri Artisan",
        medium: "Pashmina Wool",
        dimensions: "200 × 100 cm",
        imageUrl: "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=1000",
        culturalSignificance: "Represents the pinnacle of Indian textile artistry and trade traditions",
        historicalContext: "Created during the Mughal period when Kashmir was a major textile center",
        school: "Kashmiri",
        yearCreated: 1750
      },
      {
        title: "Amber Palace",
        description: "A magnificent example of Rajput architecture blending Hindu and Islamic styles. The palace showcases intricate mirror work, frescoes, and architectural innovations.",
        period: "16th Century",
        region: "Rajasthan",
        category: "monuments",
        artist: "Raja Man Singh I",
        medium: "Red Sandstone and Marble",
        dimensions: "Palace Complex",
        imageUrl: "https://images.unsplash.com/photo-1587474260584-136574528ed5?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=1000",
        culturalSignificance: "Demonstrates the architectural fusion during Mughal-Rajput alliance",
        historicalContext: "Built during the reign of Akbar as a symbol of Mughal-Rajput cooperation",
        school: "Rajput-Mughal",
        yearCreated: 1592
      },
      {
        title: "Warli Folk Art",
        description: "Traditional tribal art form using geometric patterns to depict daily life, nature, and celebrations. This artwork represents the unbroken tradition of indigenous Indian art.",
        period: "Traditional, Ongoing",
        region: "Maharashtra",
        category: "paintings",
        artist: "Warli Tribe",
        medium: "Natural Pigments on Mud Wall",
        dimensions: "Variable",
        imageUrl: "https://images.unsplash.com/photo-1515552726023-7125c8d07fb3?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=1000",
        culturalSignificance: "Preserves ancient tribal traditions and connection to nature",
        historicalContext: "Continuous tradition spanning over 2500 years",
        school: "Warli",
        yearCreated: null
      },
      {
        title: "Temple Sculpture",
        description: "Ancient stone carving depicting mythological scenes from Hindu epics. The intricate details showcase the mastery of stone carving techniques of ancient Indian artisans.",
        period: "7th Century",
        region: "Karnataka",
        category: "sculptures",
        artist: "Chalukya Sculptor",
        medium: "Sandstone",
        dimensions: "150 × 90 cm",
        imageUrl: "https://images.unsplash.com/photo-1582510003544-4d00b7f74220?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=1000",
        culturalSignificance: "Represents the integration of spirituality and artistic expression",
        historicalContext: "Created during the Western Chalukya dynasty",
        school: "Chalukya",
        yearCreated: 650
      },
      {
        title: "Illustrated Manuscript",
        description: "A beautifully illuminated manuscript featuring intricate calligraphy and miniature paintings with gold leaf details. Represents the scholarly and artistic traditions of medieval India.",
        period: "15th Century",
        region: "Gujarat",
        category: "paintings",
        artist: "Jain Monk Scribe",
        medium: "Ink and Gold on Palm Leaf",
        dimensions: "30 × 20 cm",
        imageUrl: "https://pixabay.com/get/gb6f3327c88e6bc2c00c3b1d938f52a632f72ff139a4cfa59019d53d7493cf669600da0129d77d2a7f0a7d1ce8691a479a36f04c887983d18eeee71f0013423f7_1280.jpg",
        culturalSignificance: "Preserves ancient knowledge and literary traditions",
        historicalContext: "Created in Jain monasteries as part of religious and cultural preservation",
        school: "Jain",
        yearCreated: 1450
      },
      {
        title: "Bidriware",
        description: "Traditional Indian metalwork featuring intricate silver inlay work on zinc and copper alloy. This piece showcases the sophisticated metallurgy techniques of medieval Indian craftsmen.",
        period: "14th Century Technique",
        region: "Karnataka",
        category: "sculptures",
        artist: "Bidar Craftsman",
        medium: "Zinc Alloy with Silver Inlay",
        dimensions: "35 × 25 cm",
        imageUrl: "https://images.unsplash.com/photo-1610375461246-83df859d849d?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=1000",
        culturalSignificance: "Represents the sophisticated metallurgy traditions of medieval India",
        historicalContext: "Developed during the Bahmani Sultanate period",
        school: "Deccan",
        yearCreated: 1400
      }
    ];

    initialArtifacts.forEach(artifact => {
      const id = randomUUID();
      const artifactWithId: Artifact = { 
        ...artifact, 
        id,
        artist: artifact.artist || null,
        medium: artifact.medium || null,
        dimensions: artifact.dimensions || null,
        culturalSignificance: artifact.culturalSignificance || null,
        historicalContext: artifact.historicalContext || null,
        school: artifact.school || null,
        yearCreated: artifact.yearCreated || null
      };
      this.artifacts.set(id, artifactWithId);
    });
  }

  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async getArtifacts(): Promise<Artifact[]> {
    return Array.from(this.artifacts.values());
  }

  async getArtifactById(id: string): Promise<Artifact | undefined> {
    return this.artifacts.get(id);
  }

  async getArtifactsByCategory(category: string): Promise<Artifact[]> {
    return Array.from(this.artifacts.values()).filter(
      artifact => artifact.category === category
    );
  }

  async getArtifactsByRegion(region: string): Promise<Artifact[]> {
    return Array.from(this.artifacts.values()).filter(
      artifact => artifact.region.toLowerCase().includes(region.toLowerCase())
    );
  }

  async getArtifactsByPeriod(period: string): Promise<Artifact[]> {
    return Array.from(this.artifacts.values()).filter(
      artifact => artifact.period.toLowerCase().includes(period.toLowerCase())
    );
  }

  async searchArtifacts(query: string): Promise<Artifact[]> {
    const searchQuery = query.toLowerCase();
    return Array.from(this.artifacts.values()).filter(artifact =>
      artifact.title.toLowerCase().includes(searchQuery) ||
      artifact.description.toLowerCase().includes(searchQuery) ||
      artifact.artist?.toLowerCase().includes(searchQuery) ||
      artifact.region.toLowerCase().includes(searchQuery) ||
      artifact.period.toLowerCase().includes(searchQuery) ||
      artifact.school?.toLowerCase().includes(searchQuery)
    );
  }

  async createArtifact(insertArtifact: InsertArtifact): Promise<Artifact> {
    const id = randomUUID();
    const artifact: Artifact = { 
      ...insertArtifact, 
      id,
      artist: insertArtifact.artist || null,
      medium: insertArtifact.medium || null,
      dimensions: insertArtifact.dimensions || null,
      culturalSignificance: insertArtifact.culturalSignificance || null,
      historicalContext: insertArtifact.historicalContext || null,
      school: insertArtifact.school || null,
      yearCreated: insertArtifact.yearCreated || null
    };
    this.artifacts.set(id, artifact);
    return artifact;
  }

  async getStories(): Promise<Story[]> {
    return Array.from(this.stories.values());
  }

  async createStory(insertStory: InsertStory): Promise<Story> {
    const id = randomUUID();
    const story: Story = { 
      ...insertStory, 
      id, 
      createdAt: new Date().toISOString()
    };
    this.stories.set(id, story);
    return story;
  }
}

export const storage = new MemStorage();
